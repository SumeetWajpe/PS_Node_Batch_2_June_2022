let courses = [
  {
    id: 1,
    title: "React",
    price: 5000,
    likes: 400,
    rating: 5,
    imageUrl:
      "https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg",
    description:
      "React is a free and open-source front-end JavaScript library for building user interfaces based on UI components. It is maintained by Meta and a community of individual developers and companies.",
    introVideo: "./videos/React.mp4",
  },
  {
    id: 2,
    title: "Redux",
    price: 4000,
    likes: 600,
    rating: 5,
    imageUrl: "https://logicalidea.co/wp-content/uploads/2020/05/Redux.jpg",
    description:
      "Redux is an open-source JavaScript library for managing and centralizing application state. It is most commonly used with libraries such as React or Angular for building user interfaces. Similar to Facebook's Flux architecture, it was created by Dan Abramov and Andrew Clark.",
    introVideo: "./videos/Redux.mp4",
  },
  {
    id: 3,
    title: "Node",
    price: 6000,
    likes: 900,
    rating: 4,
    imageUrl:
      "https://i0.wp.com/css-tricks.com/wp-content/uploads/2022/01/node-js-logo.png?fit=1200%2C600&ssl=1",
    description:
      "Node.js is an open-source, cross-platform, back-end JavaScript runtime environment that runs on the V8 engine and executes JavaScript code outside a web browser, which was designed to build scalable network applications. ",
    introVideo: "./videos/Node.mp4",
  },
  {
    id: 4,
    title: "Angular",
    price: 5000,
    likes: 200,
    rating: 3,
    imageUrl:
      "https://www.trio.dev/hubfs/Imported_Blog_Media/7fad34d867a32f732b37534ff013e916-3-2.jpg",
    description:
      "Angular is a TypeScript-based free and open-source web application framework led by the Angular Team at Google and by a community of individuals and corporations. Angular is a complete rewrite from the same team that built AngularJS.",
    introVideo: "./videos/Angular.mp4",
  },
  {
    id: 5,
    title: "Flutter",
    price: 7000,
    likes: 700,
    rating: 4,
    imageUrl: "https://miro.medium.com/max/2000/1*PCKC8Ufml-wvb9Vjj3aaWw.jpeg",
    description:
      "Flutter is an open-source UI software development kit created by Google. It is used to develop cross platform applications for Android, iOS, Linux, macOS, Windows, Google Fuchsia, and the web from a single codebase. First described in 2015, Flutter was released in May 2017.",
    introVideo: "./videos/Flutter.mp4",
  },
];

module.exports = courses;

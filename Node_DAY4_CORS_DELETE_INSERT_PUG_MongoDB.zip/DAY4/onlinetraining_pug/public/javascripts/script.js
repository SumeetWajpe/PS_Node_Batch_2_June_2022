function Initialize() {
  var allDeleteButtons = document.querySelectorAll(".delete-course");
  for (const btn of allDeleteButtons) {
    btn.addEventListener("click", () => DeleteACourse(btn.id));
  }
}

window.addEventListener("DOMContentLoaded", Initialize);

function DeleteACourse(theCourseId) {
  fetch(`http://localhost:3000/delete/${theCourseId}`, {
    method: "DELETE",
  })
    .then((res) => res.json())
    .then((message) => {
      window.location.href = "/";
    });
}

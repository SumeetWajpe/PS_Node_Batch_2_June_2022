var express = require("express");
const { MongoClient } = require("mongodb");
var router = express.Router();
//const courses = require("../model/course.model");
const fs = require("fs");
var courses = [];
/* GET home page. */
router.get("/", function (req, res, next) {
  // mongodb
  const url = "mongodb://localhost:27017";
  const client = new MongoClient(url);
  client.connect((err, dbconn) => {
    if (err) console.log(err);
    else {
      let coursesColl = dbconn.db("onlinetrainingdb").collection("courses");

      coursesColl.find({}).toArray((err, result) => {
        if (err) console.log(err);
        else {
          courses = result;
          res.render("courses", { title: "List Of Courses", courses });
        }
      });
    }
  });

  //
});

router.get("/coursedetails/:id", (req, res) => {
  console.log(courses);
  let courseId = +req.params.id;
  console.log(courseId);
  let theCourse = courses.find((c) => c.id == courseId);
  console.log(theCourse);

  res.render("coursedetails", { theCourse });
});

router.get("/courses/video/:id", (req, res) => {
  let courseId = +req.params.id;
  let theCourse = courses.find((c) => c.id === courseId);

  // get video stats
  const videopath = theCourse.introVideo;
  const videosize = fs.statSync(videopath).size;

  // range
  const range = req.headers.range;
  const CHUNK_SIZE = 10 ** 6; // 1MB
  const start = Number(range.replace(/\D/g, ""));
  const end = Math.min(start + CHUNK_SIZE, videosize - 1);

  // headers
  const contentLength = end - start + 1;
  const headers = {
    "Content-Range": `bytes ${start}-${end}/${videosize}`,
    "Accept-Ranges": "bytes",
    "Content-Length": contentLength,
    "Content-Type": "video/mp4",
  };

  res.writeHead(206, headers);
  // streaming logic
  const videoStream = fs.createReadStream(videopath, { start, end });
  videoStream.pipe(res); // stream the video to the client !
});

router.post("/newcourse", (req, res) => {
  console.log("Adding new course");
  let newCourse = req.body;
  courses.push(newCourse);
  console.log(courses);
  res.json({ msg: "success" });
});

router.delete("/delete/:id", (req, res) => {
  if (req.params.id) {
    let theCourseId = +req.params.id; // can use parseInt()
    let theCourseIndex = courses.findIndex((c) => c.id === theCourseId);
    let deletedCourse = courses.splice(theCourseIndex, 1);
    if (deletedCourse) {
      res.json({ deletedCourse: deletedCourse[0], msg: "success" });
    } else {
      res.statusCode = 404;
      res.send("Something went wrong !");
    }
  }
});

module.exports = router;

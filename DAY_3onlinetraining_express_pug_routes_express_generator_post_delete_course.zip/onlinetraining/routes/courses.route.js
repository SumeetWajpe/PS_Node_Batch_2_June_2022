const express = require("express");
const router = express.Router();
const courses = require("../models/course.model");

router.get("/", (req, res) => {
  res.json(courses);
});

router.post("/newcourse", (req, res) => {
  console.log("Adding new course");
  let newCourse = req.body;
  courses.push(newCourse);
  console.log(courses);
  res.json({ msg: "success" });
});

router.delete("/delete/:id", (req, res) => {
  if (req.params.id) {
    let theCourseId = +req.params.id; // can use parseInt()
    let theCourseIndex = courses.findIndex((c) => c.id === theCourseId);
    let deletedCourse = courses.splice(theCourseIndex, 1);
    if (deletedCourse) {
      res.json({ deletedCourse: deletedCourse[0], msg: "success" });
    } else {
      res.statusCode = 404;
      res.send("Something went wrong !");
    }
  }
});
module.exports = router;

const http = require("http");
const fs = require("fs");
const hostname = "127.0.0.1";
const port = 3000;

const server = http.createServer((req, res) => {
  if (req.url == "/" || req.url == "/Index.html") {
    fs.readFile("Index.html", (err, data) => {
      // if err
      res.statusCode = 200;
      res.setHeader("Content-Type", "text/html");
      res.end(data.toString());
    });
  } else if (req.url == "/script.js") {
    fs.readFile("script.js", (err, data) => {
      // if err
      res.statusCode = 200;
      res.setHeader("Content-Type", "text/javascript");
      res.end(data.toString());
    });
  } else if (req.url == "/styles.css") {
    fs.readFile("styles.css", (err, data) => {
      // if err
      res.statusCode = 200;
      res.setHeader("Content-Type", "text/css");
      res.end(data.toString());
    });
  } else if (req.url == "/products") {
    var products = [
      { id: 1, name: "Mac Book Pro", price: 250000 },
      { id: 2, name: "IPhone", price: 80000 },
    ];
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify(products));
  }
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});

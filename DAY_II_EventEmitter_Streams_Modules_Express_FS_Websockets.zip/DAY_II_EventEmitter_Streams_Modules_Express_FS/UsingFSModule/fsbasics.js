const fs = require("fs"); // built-in

// non - blocking
// fs.readFile("Input.txt", (err, dataFromFile) => {
//   if (err) console.log(err);
//   else console.log("File Contents (Async) : " + dataFromFile);
// });

// blocking
let dataFromFile = fs.readFileSync("Input.txt");
console.log("File Contents : (Read sync) - " + dataFromFile);
console.log("Program Ended !");

var mathmodule = require("./math");
console.log(`The addition is ${mathmodule.Add(20, 30)}`);
console.log(`The product is ${mathmodule.Multiplication(20, 30)}`);


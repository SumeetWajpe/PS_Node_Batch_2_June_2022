import  { Add, Product } from "./math.js";
console.log(`The addition is ${Add(20, 30)}`);
console.log(`The product is ${Product(20, 30)}`);

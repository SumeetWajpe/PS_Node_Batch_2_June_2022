const fs = require("fs");

let readableStream = fs.createReadStream("Input.txt");
let writableStream = fs.createWriteStream("Output.txt");

let allData = "";
// readableStream.on("data", (chunk) => {
//   //   console.log(chunk.toString());
//   console.log(
//     "\n\r>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> CHUNK >>>>>>>>>>>>>>>>>>>>>> \n\r"
//   );
//   allData += chunk;
// });

// readableStream.on("error", (err) => {
//   console.log(err);
// });
// readableStream.on("end", () => {
//   writableStream.write(allData);
//   writableStream.end();
// });

// OR

readableStream.pipe(writableStream);

console.log("Program Ended !");

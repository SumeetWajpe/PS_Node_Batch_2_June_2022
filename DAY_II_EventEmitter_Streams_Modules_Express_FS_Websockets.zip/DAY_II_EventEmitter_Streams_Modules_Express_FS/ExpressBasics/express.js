const express = require("express");
const app = express(); // represents an application

app.get("/", (req, res) => {
  //   res.send("Hello Express !");
  //   res.send("<h1>Hello Express ! </h1>");
  //   res.sendFile("Index.html", { root: __dirname });

  res.json([
    { id: 1, name: "Mac Book Pro", price: 250000 },
    { id: 2, name: "IPhone", price: 80000 },
  ]);
});

app.listen(4000, () => {
  console.log("Express running at 4000 !");
});

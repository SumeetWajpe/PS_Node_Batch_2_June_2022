const EventEmitter = require("events").EventEmitter;

// publisher
function GetCount(maxIteration) {
  let evt = new EventEmitter();
  // logic -> emit
  process.nextTick(() => {
    evt.emit("start");
    let count = 0;
    let timerId = setInterval(() => {
      e.emit("count", ++count);

      if (count == 8) {
        e.emit("error", count);
        clearInterval(timerId);
      }

      if (count == maxIteration) {
        e.emit("finish", count);
        clearInterval(timerId);
      }
    }, 500);
  }, 2000);
  return evt;
}

// subscriber

var e = GetCount(10); // returns an event emitter
// e.on("start", () => {
//   console.log("Iteration started..");
// });

e.on("count", (theCount) => {
  console.log("Count received : " + theCount);
});

// e.on("finish", (theCount) => {
//   console.log("Final Count received : " + theCount);
// });

e.on("error", (theCount) => {
  console.log("Ended With Error, Count received : " + theCount);
});

import Addition, { Product } from "./Math.js";
console.log("The addition is : " + Addition(20, 40));
console.log("The multiplication is : " + Product(20, 40));
